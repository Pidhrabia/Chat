function openbox(id){
        display = document.getElementById(id).style.display = 'block';
}
    
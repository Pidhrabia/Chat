$(function(){
  $('.slider').slick({
        arrows: false,
        fade: true,
        autoplay: 5000,
        dots: false,
    
   });
});

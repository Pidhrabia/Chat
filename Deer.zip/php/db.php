<?php
    $mysql = new mysqli('localhost', 'root', 'root', 'deer');
?>